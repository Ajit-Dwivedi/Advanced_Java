package dao;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import pojos.Book;
import utils.DBUtils;

class TestBookDao {
	private static BookDaoImpl bookDao;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		DBUtils.openConnection();
		bookDao=new BookDaoImpl();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		bookDao.cleanUp();
		DBUtils.closeConnection();
	}

	@Test
	void test() throws Exception{
		List<Book> list=bookDao.getAllBooks();//.forEach(System.out::println);
		assertEquals(10, list.size());
		
	}

}
