package beans;

import java.sql.SQLException;
import java.util.List;

import dao.BookDaoImpl;
import pojos.Book;

public class BookBean {
//state : properties : dependency
	private BookDaoImpl bookDao;
	//clnt's conversational state
	private String title;
	private String author;
	private String category;
	private double price;
	
	//ctor
	public BookBean() throws SQLException {
		bookDao=new BookDaoImpl();
		System.out.println("book bean created");
	}
	//setter n getter
	public BookDaoImpl getBookDao() {
		return bookDao;
	}
	public void setBookDao(BookDaoImpl bookDao) {
		this.bookDao = bookDao;
	}
	//setters
	
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	//B.L method for getting all books
		public List<Book> fetchAllBooks() throws SQLException
		{
			System.out.println("in JB : fetch all books");
			return bookDao.getAllBooks();
		}
		//B.L method to add a new book to the DB
		public String addNewBook() throws SQLException
		{
			System.out.println("in B.L method add new book "+title+" "+price);
			//create Book instance : TRANSIENT
			Book newBook=new Book(title, author, category, price);
			return bookDao.addBook(newBook);
		}
}
