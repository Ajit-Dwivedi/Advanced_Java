package dao;

import java.sql.SQLException;
import java.util.List;

import pojos.Book;

public interface BookDao {
//add a method to return all books to the caller
	List<Book> getAllBooks() throws SQLException;
	//add a method to add new book
	String addBook(Book newBook) throws SQLException;
}
