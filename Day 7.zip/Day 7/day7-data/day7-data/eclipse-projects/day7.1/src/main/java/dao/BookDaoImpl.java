package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import pojos.Book;
import static utils.DBUtils.getConnection;

public class BookDaoImpl implements BookDao {
	private Connection cn;
	private PreparedStatement pst1, pst2;

	public BookDaoImpl() throws SQLException {
		cn = getConnection();
		pst1 = cn.prepareStatement("select * from books");
		pst2 = cn.prepareStatement("insert into books values(default,?,?,?,?)");
		System.out.println(" book dao created...");
	}

	@Override
	public List<Book> getAllBooks() throws SQLException {
		List<Book> books = new ArrayList<>();
		try (ResultSet rst = pst1.executeQuery()) {
			// bookId, String title, String author, String category, double price
			while (rst.next())
				books.add(new Book(rst.getInt(1), rst.getString(2), rst.getString(3), rst.getString(4),
						rst.getDouble(5)));
		}
		return books;
	}

	@Override
	public String addBook(Book newBook) throws SQLException {
		try {
			// set IN params : title | author | category | price
			pst2.setString(1, newBook.getTitle());
			pst2.setString(2, newBook.getAuthor());
			pst2.setString(3, newBook.getCategory());
			pst2.setDouble(4, newBook.getPrice());
			// exec update
			int updateCount = pst2.executeUpdate();
			if (updateCount == 1)
				return "Added Book !";
		} catch (Exception e) {
			return "Adding book failed " + e.getMessage();
		}
		return "Adding book failed ";

	}

	public void cleanUp() throws SQLException {
		if (pst1 != null)
			pst1.close();
		if (pst2 != null)
			pst2.close();
		System.out.println("book dao cleaned up !");
	}

}
