package dao;

import pojos.User;
import org.hibernate.*;
import static utils.HibernateUtils.getFactory;

import java.io.Serializable;

public class UserDaoImpl implements UserDao {

	@Override
	public String registerUser(User newUser) {
		String mesg = "User registration failed!!!!!!!!!!";
		// 1. get hibernate session from SF(SessionFactory)
		Session session = getFactory().openSession();
		Session session2 = getFactory().openSession();
		System.out.println("same or different " + (session == session2));// false
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		System.out.println("session open " + session.isOpen() + " is conncted " + session.isConnected());// t t
		try {
			// save user details
			Integer id = (Integer) session.save(newUser);
			// upon success : commit Tx
			tx.commit();
			mesg = "User registered with ID " + id;
			System.out.println("session open " + session.isOpen() + " is conncted " + session.isConnected());// t t

		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exc to the caller
			throw e;
		} finally {
			// close session
			if (session != null)
				session.close();
		}
		System.out.println("session open " + session.isOpen() + " is conncted " + session.isConnected());// f f

		return mesg;
	}

	@Override
	public String registerUserViaGetCurrentSession(User newUser) {
		String mesg = "User registration failed!!!!!!!!!!";
		// 1. get hibernate session from SF(SessionFactory)
		Session session = getFactory().getCurrentSession();
		Session session2 = getFactory().getCurrentSession();
		System.out.println("same or different " + (session == session2));// true
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		System.out.println("session open " + session.isOpen() + " is conncted " + session.isConnected());// t t
		try {
			// save user details
			Integer id = (Integer) session.save(newUser);
			// upon success : commit Tx
			tx.commit();
			mesg = "User registered with ID " + id;
			System.out.println("session open " + session.isOpen() + " is conncted " + session.isConnected());// f f

		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exc to the caller
			System.out.println("session open " + session.isOpen() + " is conncted " + session.isConnected());// f f
			throw e;
		}
		return mesg;
	}

	@Override
	public User getUserDetailsById(int userId) {
		User user = null;
		// 1. get hibernate session from SF(SessionFactory)
		Session session = getFactory().getCurrentSession();
		// 2. Begin Tx
		Transaction tx = session.beginTransaction();
		try {
			// get user details by id
			user = session.get(User.class, userId);// int ---> Integer ---> Serializable
			// upon success : commit Tx
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			// re throw the exc to the caller
			throw e;
		}

		return user;
	}

}
