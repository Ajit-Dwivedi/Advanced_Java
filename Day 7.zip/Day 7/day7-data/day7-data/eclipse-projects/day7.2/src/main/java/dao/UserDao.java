package dao;

import pojos.User;

public interface UserDao {
//add a method to register user : via openSession
	String registerUser(User newUser);

	// add a method to register user : via getCurrentSession
	String registerUserViaGetCurrentSession(User newUser);
	// add a method to get user details by it's id
    User getUserDetailsById(int userId);
}
