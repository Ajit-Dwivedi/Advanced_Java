package tester;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import dependent.ATMImpl;

public class TestSpring {

	public static void main(String[] args) {
		try (ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("bean-config.xml")) {
			System.out.println("SC up n running .....");
			// get atm bean for invoking B.L
			ATMImpl atm1 = ctx.getBean("my_atm", ATMImpl.class);
			atm1.deposit(12345);
			ATMImpl atm2 = ctx.getBean("my_atm", ATMImpl.class);
			System.out.println(atm1 == atm2);// true/false
		} // JVM : ctx.close() => shut down SC --> SC chks --destroy : for singleton beans
			// --invokes the same --bean will be marked GC
		catch (Exception e) {
			e.printStackTrace();
		}

	}

}
