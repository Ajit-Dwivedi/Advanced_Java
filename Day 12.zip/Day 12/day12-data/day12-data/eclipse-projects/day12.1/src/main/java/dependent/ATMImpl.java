package dependent;

import dependency.Transport;

public class ATMImpl implements ATM {
	private Transport myTransport;


	private ATMImpl() {
		
		System.out.println("in cnstr of " + getClass().getName() + " " + myTransport);
	}

	@Override
	public void deposit(double amt) {
		System.out.println("depositing " + amt);
		byte[] data = ("depositing " + amt).getBytes();
		myTransport.informBank(data);

	}

	@Override
	public void withdraw(double amt) {
		System.out.println("withdrawing " + amt);
		byte[] data = ("withdrawing " + amt).getBytes();
		myTransport.informBank(data);
	}	

	// custom init method
	public void myInit() {
		System.out.println("in init " + myTransport);
	}

	// custom destroy method
	public void myDestroy() {
		System.out.println("in destroy " + myTransport);
	}
	//setter 

	public void setMyTransport(Transport myTransport) {
		this.myTransport = myTransport;
		System.out.println("in set transport "+this.myTransport);
	}
	
}
