package com.app.controller;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller //Mandatory cls level anno to tell SC : following is a req handling controller : spring bean
//singleton n eager
public class HelloController {
	public HelloController() {
		System.out.println("in ctor of "+getClass());
	}
	@PostConstruct
	public void init()
	{
		System.out.println("in init");
	}
	//mandatory method level anno : for mapping url-pattern --> method of the handler
	@RequestMapping("/hello")
	public String sayHello()
	{
		System.out.println("in say hello");
		return "/welcome";//Handler rets Logical view Name(forward view name) ---> D.S
	}
	
	
	
	
	

}
