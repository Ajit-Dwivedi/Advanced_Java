package config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration // to tell SC , following class can contain spring bean defs(LATER)
//will auto enable anno support
@ComponentScan(basePackages = { "dependent", "dependency" })
public class AppConfig {

}
