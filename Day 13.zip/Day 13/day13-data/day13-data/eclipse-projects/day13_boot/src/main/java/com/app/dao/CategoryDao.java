package com.app.dao;

import java.util.List;

import com.app.pojos.Category;

public interface CategoryDao {
//add a method to get all categories
	List<Category> getAllCategories();
}
