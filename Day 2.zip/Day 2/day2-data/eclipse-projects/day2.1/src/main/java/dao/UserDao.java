package dao;

import java.sql.SQLException;

import pojos.User;

public interface UserDao {
//add a method for user's sign in
	User authenticateUser(String email,String password) throws SQLException;
	String registerUser(User user) throws SQLException;
}
