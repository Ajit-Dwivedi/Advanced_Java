package dao;

import java.util.List;

import pojos.Candidates;

public interface CandidateDao {
	
	List<Candidates> getAllCandidate();

}
