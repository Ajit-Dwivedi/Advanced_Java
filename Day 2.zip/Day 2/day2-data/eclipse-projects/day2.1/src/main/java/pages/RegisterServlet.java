package pages;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import pojos.*;
import dao.*;
import utils.*;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet(value = "/Register",loadOnStartup = 1)
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	UserDaoImpl userDao;

	public void init() throws ServletException {
		
		try {
			DBUtils.openConnection();
			userDao = new UserDaoImpl();
		} catch (SQLException e) {
			
			throw new ServletException("err in intit of "+ getClass(),e);
			
		}
		
		System.out.println(" in init");
		
	}

	
	public void destroy() {
		try {
			userDao.cleanUp();
			DBUtils.closeConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		User user = new User();
		
		user.setUserId(0);
		user.setFirstName(request.getParameter("fname"));
		user.setLastName(request.getParameter("lname"));
		user.setEmail(request.getParameter("mail"));
		user.setPassword(request.getParameter("pass"));
		user.setDob(Date.valueOf(request.getParameter("dob")));
		user.setStatus(false);
		user.setRole(request.getParameter("role"));
		
		response.setContentType("text/html");
		
		String msg = "";
		
		System.out.println("in do post");
		
		try {
			 msg = userDao.registerUser(user);
			response.getWriter().println("<h3>" + msg +"</h3>"+"<a href = 'login.html'>login</a>");
			
			System.out.println("in do post try");
		} catch (SQLException e) {
			msg = "internal server Error";
			e.printStackTrace();
		}
		
	}

}
