package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import static utils.DBUtils.getConnection;

import pojos.User;

public class UserDaoImpl implements UserDao {
	private Connection cn;
	private PreparedStatement pst1,pst2;

	// def ctor : get cn from utils , create pst1
	public UserDaoImpl() throws SQLException {
		// get db cn from DB utils
		cn = getConnection();
		pst1 = cn.prepareStatement("select * from users where email=? and password=?");
		//insert into users(default,first_name,last_name,email,password,dob,default,role)
		pst2 = cn.prepareStatement("insert into users values(default,?,?,?,?,?,?,?)"); 
		System.out.println("user dao created !");
	}

	/*
	 * int userId, String firstName, String lastName, String email, String password,
	 * Date dob, boolean status, String role)
	 */
	@Override
	public User authenticateUser(String email, String password) throws SQLException {
		// set IN params
		pst1.setString(1, email);
		pst1.setString(2, password);
		// exec the query to ret ResultSet
		try (ResultSet rst = pst1.executeQuery()) {
			if (rst.next()) // => valid login
				return new User(rst.getInt(1), rst.getString(2), 
						rst.getString(3), email, password, rst.getDate(6),
						rst.getBoolean(7), rst.getString(8));
		}
		return null;
	}
	
	@Override
	public String registerUser(User user) throws SQLException {
		
		
		pst2.setString(1, user.getFirstName());
		pst2.setString(2, user.getLastName());
		pst2.setString(3, user.getEmail());
		pst2.setString(4, user.getPassword());
		pst2.setDate(5, user.getDob());
		pst2.setBoolean(6,user.isStatus());
		pst2.setString(7, user.getRole());
		
		
		
		int res = -1;
		
		res = pst2.executeUpdate();
		
		return  (res == 1)? "user registration succesfully ":"Error in user registraion";
	}


	// add a method to clean db resource (psts)
	public void cleanUp() throws SQLException {
		if (pst2 != null)
			pst2.close();
		System.out.println("user dao cleaned up !");
	}

	
}
