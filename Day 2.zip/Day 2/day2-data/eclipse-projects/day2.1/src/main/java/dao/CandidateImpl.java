package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import static utils.DBUtils.*;

import pojos.Candidates;

public class CandidateImpl implements CandidateDao{
	
	private Connection cnn;
	private PreparedStatement pst;
	
	public CandidateImpl() throws SQLException {
		
		cnn = getConnection();
		pst = cnn.prepareStatement("select * from candidates");
	}
	
	
	

	@Override
	public List<Candidates> getAllCandidate() {
		
		
		
		return null;
	}

}
