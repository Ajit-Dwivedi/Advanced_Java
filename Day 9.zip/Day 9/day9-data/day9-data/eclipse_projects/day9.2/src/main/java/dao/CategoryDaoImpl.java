package dao;

import pojos.Category;
import static utils.HibernateUtils.getFactory;

import org.hibernate.*;

public class CategoryDaoImpl implements CategoryDao {

	@Override
	public String addNewCategory(Category category) {
		String mesg = "Adding category failed!!!!!!!";
		// get session from SF
		Session session = getFactory().getCurrentSession();
		// begin Tx
		Transaction tx = session.beginTransaction();
		try {
			session.persist(category);
			tx.commit();
			mesg = "Added new category with ID " + category.getId();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}

}
