package tester;

import org.hibernate.SessionFactory;

import dao.CategoryDaoImpl;
import dao.ProductDaoImpl;
import pojos.Category;
import pojos.Product;

import static utils.HibernateUtils.getFactory;

import java.util.Scanner;

public class AddNewProductToExistingCategory {

	public static void main(String[] args) {
		try (SessionFactory sf = getFactory(); Scanner sc = new Scanner(System.in)) {
			System.out.println("Hibernate up n running " + sf);
			ProductDaoImpl dao=new ProductDaoImpl();
			System.out.println("Enter category id");
			long categoryId=sc.nextLong();
			System.out.println("Enter product details : productName");
			sc.nextLine();
			String prodName=sc.nextLine();
			System.out.println("Enter price");
			double price=sc.nextDouble();
			System.out.println("Enter product desc");
			sc.nextLine();
			String description=sc.nextLine();
			System.out.println(dao.addProductToCategory(categoryId, new Product(prodName, price, description)));
			} // JVM : sf.close ==> closing of SF : cn pool !

	}

}
