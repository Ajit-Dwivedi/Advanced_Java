package dao;

import pojos.Category;

public interface CategoryDao {
	String addNewCategory(Category category);
}
