package tester;

import org.hibernate.SessionFactory;

import dao.CategoryDaoImpl;
import dao.ProductDaoImpl;
import pojos.Category;
import pojos.Product;

import static utils.HibernateUtils.getFactory;

import java.util.Scanner;

public class AddNewCategoryWithProducts {

	public static void main(String[] args) {
		try (SessionFactory sf = getFactory(); Scanner sc = new Scanner(System.in)) {
			System.out.println("Hibernate up n running " + sf);
			CategoryDaoImpl categoryDao = new CategoryDaoImpl();
			System.out.println("Enter category details : categoryName");
			String name = sc.nextLine();
			System.out.println("Enter category desc ");
			Category category = new Category(name, sc.nextLine());
			for (int i = 0; i < 3; i++) {
				System.out.println("Enter product details : productName");
				String prodName = sc.nextLine();
				System.out.println("Enter price");
				double price = sc.nextDouble();
				System.out.println("Enter product desc");
				sc.nextLine();
				String description = sc.nextLine();
				Product p = new Product(prodName, price, description);
				//establish bi dir link
				category.addProduct(p);
			}
			System.out.println(categoryDao.addNewCategory(category));
		} // JVM : sf.close ==> closing of SF : cn pool !

	}

}
