package dao;

import pojos.Product;

public interface ProductDao {
//add a method to add a product to existing category
	String addProductToCategory(Long categoryId,Product newProduct);
}
