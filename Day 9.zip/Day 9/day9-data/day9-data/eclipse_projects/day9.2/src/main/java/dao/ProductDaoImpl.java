package dao;

import pojos.Category;
import pojos.Product;

import static utils.HibernateUtils.getFactory;

import org.hibernate.*;

public class ProductDaoImpl implements ProductDao {

	@Override
	public String addProductToCategory(Long categoryId, Product newProduct) {
		String mesg="Adding product failed..";
		// 1. get Session from SF
		Session session = getFactory().getCurrentSession();
		// 2. Begin a Tx
		Transaction tx = session.beginTransaction();
		try {
			//3. get category from it's id
			Category category=session.get(Category.class, categoryId);
			if(category != null) {
				//=> category exists
				//establish bi dir asso .
				category.addProduct(newProduct);
				session.persist(newProduct);
			}
			
			tx.commit();
			mesg="added product with ID "+newProduct.getId();
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}

}
