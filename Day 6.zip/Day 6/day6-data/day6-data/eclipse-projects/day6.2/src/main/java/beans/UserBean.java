package beans;

import java.sql.SQLException;

import dao.UserDaoImpl;
import pojos.User;

public class UserBean {
//state
	private String email;
	private String password;
	private User userDetails;
	private UserDaoImpl userDao;
	private String message;

	// def ctor
	public UserBean() throws SQLException {
		System.out.println("in user bean ctor");
		userDao = new UserDaoImpl();
		System.out.println("user bean created...");
	}
//setters n getters

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public User getUserDetails() {
		return userDetails;
	}

	public void setUserDetails(User userDetails) {
		this.userDetails = userDetails;
	}

	public UserDaoImpl getUserDao() {
		return userDao;
	}

	public void setUserDao(UserDaoImpl userDao) {
		this.userDao = userDao;
	}

	public String getMessage() {
		return message;
	}

	// Add B.L method for validating user
	public String validateUser() throws SQLException {
		System.out.println("in validate user " + email + " " + password);
		// invoke DAO's method for user authentication
		userDetails = userDao.authenticateUser(email, password);
		if (userDetails == null)// => invalid login
		{
			message="Invalid Login , Please retry !!!!!!!!!!!!";
			return "login";// JB rets navigational outcome to the caller(JSP)
		}		
		// => valid login
		message="Login Successful ....";
		if (userDetails.getRole().equals("admin"))
			return "admin";
		// => voter : user
		if (userDetails.isStatus())
			return "logout"; // voter : alrdy voted
		return "list"; // voter not yet voted
	}

}
