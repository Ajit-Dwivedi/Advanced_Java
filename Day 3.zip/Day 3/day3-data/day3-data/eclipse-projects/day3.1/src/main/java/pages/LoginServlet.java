package pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.cj.jdbc.exceptions.SQLError;

import dao.UserDaoImpl;
import pojos.User;

import static utils.DBUtils.*;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet(value = "/authenticate", loadOnStartup = 1)
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDaoImpl userDao;

	/**
	 * @see Servlet#init()
	 */
	// javac rule : Overriding form of the method CAN NOT add any NEW or BROADER
	// CHECKED excs
	public void init() throws ServletException {
		System.out.println("in init");
		try {
			// open cn
			openConnection();
			// create dao instance
			userDao = new UserDaoImpl();
		} catch (Exception e) {
			// e.printStackTrace();
			// re throw the excpetion to the caller (WC) --> to inform failure of the init
			// method : so that WC DOES NOT continue with the remaining life cycle
			// API : ServletException(String mesg,Throwable rootCause)
			throw new ServletException("err in init of " + getClass(), e);
		}

	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// user dao's cleanup
		try {
			userDao.cleanUp();
			// close cn
			closeConnection();
		} catch (SQLException e) {
			// re throw the exc to the caller
			throw new RuntimeException("err in destroy of " + getClass(), e);
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("in do-post");
		// 1. set resp cont type
		response.setContentType("text/html");
		try (PrintWriter pw = response.getWriter()) {
			// read req params
			// API of ServletRequest i/f
			// public String getParameter(String paramName)
			String email = request.getParameter("em");
			String pwd = request.getParameter("pass");

			// invoke dao's method for user authentication
			User user = userDao.authenticateUser(email, pwd);
			
			System.out.println(user.toString());
			// => no exc
			// chk for valid or invalid login
			if (user == null) // => invalid login
				pw.print("<h5>Invalid Login , Please   <a href='login.html'>Retry </a></h5>");
			else { //=> valid login 
				//1. create a cookie
				//Cookie c1=new Cookie("user_details",user.toString()); --  not working plz check
				Cookie c1=new Cookie("user_details",user.getFirstName());
				//2. Add the cookie to resp header
				response.addCookie(c1);
				//authentication is successful --> proceed to role based authorization
				if(user.getRole().equals("admin")) //=> valid admin login
					//redirect the clnt in the NEXT request to admin page
					//API : HttpServletResponse : public void sendRedirect(String redirectLoc) throws IOExc
					response.sendRedirect("admin_page");
				else  //=> valid voter login
				{
					pw.print("<h3> From login page </h3>");
			//		pw.flush(); un comment this line to chk the exc
					if(user.isStatus())//=> voter alrdy voted
						response.sendRedirect("logout");
					else //=> voter not yet voted
						response.sendRedirect("list");
					/*
					 * What will WC do upon resp.sendRedirect(...);
					 * 1. Clrs(empties) the resp buffer
					 * 2. sends temp redirect resp
					 * SC : 302 | Header : Location : list/logout/admin_page + Set-Cookie : user_details : admin's details | body : EMPTY
					 * 3. Clnt browser sends NEW request
					 * URL : http://host:port/day3.1/list , method=GET
					 * req header : Cookie : user_details : admin's detail
					 */
						
				}
					
		}

		} catch (Exception e) {
			throw new ServletException("err in do-post of " + getClass(), e);
		}
	}

}
