package pages;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import pojos.User;

/**
 * Servlet implementation class CandidateListServlet
 */
@WebServlet("/list")
public class CandidateListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		try (PrintWriter pw = response.getWriter()) {
			pw.print("<h5>in candidate list </h5>");
			// How to get user details from the HttpSession (=session scope)
			//1. get HttpSession from WC
			HttpSession session=request.getSession();
			System.out.println("from list page "+session.getId());//same session id for the same clnt : provided cookies are enabled 
			System.out.println("session is new "+session.isNew());//false :  for the same clnt : provided cookies are enabled
			//2. get details
			User userDetails=(User)session.getAttribute("user_info");
			if(userDetails != null)
				pw.print("<h4> User Details from HttpSession "+userDetails+"</h4>");
			 else
				pw.print("<h4>No Cookies : Session Tracking Failed!!!!!!!!!!!!!!!!!!!!!!</h4>");
		}
	}

}
