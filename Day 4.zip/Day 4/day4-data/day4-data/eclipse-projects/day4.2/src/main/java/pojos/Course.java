package pojos;

public enum Course {
JAVA(80),MERN(84),REACT(76),MONGO_DB(70),CSHARP(79);
	private int minScore;

	private Course(int minScore) {
		this.minScore = minScore;
	}

	public int getMinScore() {
		return minScore;
	}
	
	

}
