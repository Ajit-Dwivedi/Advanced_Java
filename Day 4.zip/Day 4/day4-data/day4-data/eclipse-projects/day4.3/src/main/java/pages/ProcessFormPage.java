package pages;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pojos.Course;
import pojos.Student;

/**
 * Servlet implementation class ProcessFormPage
 */
@WebServlet("/process_form")
public class ProcessFormPage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("in do-post of " + getClass());
		response.setContentType("text/html");
		try (PrintWriter pw = response.getWriter()) {
			pw.print("from 1st page...");
			pw.flush();
			// 1. Create student object , using req params
			Course course = Course.valueOf(request.getParameter("course"));
			int score = Integer.parseInt(request.getParameter("score"));
			Student student = new Student(request.getParameter("fname"), request.getParameter("lname"), score, course);
			// 2. check score
			if (score >= course.getMinScore())
				student.setAdmissionStatus(true);
			// 3. Add student details under request scope : setAttribute(nm,val)
			request.setAttribute("student_dtls", student);
			// 4. create RD
			RequestDispatcher rd = request.getRequestDispatcher("result");
			// 5. forward
			rd.include(request, response);
			// WC :
			/*
			 * 1. suspends the exec of the curnt method 
			 * 
			 * 2. WC calls doPost of the next resource
			 * 3. After it's completion , control comes back --continues....
			 */
			System.out.println("control came back .....");
			pw.print("<h5>Content post include ....</h5>");
		}//committing the resp 
	}

}
