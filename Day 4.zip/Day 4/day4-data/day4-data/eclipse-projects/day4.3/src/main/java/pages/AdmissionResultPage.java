package pages;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pojos.Student;

/**
 * Servlet implementation class AdmissionResultPage
 */
@WebServlet("/result")
public class AdmissionResultPage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		System.out.println("in do-post of " + getClass());
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		pw.print(" <h4> from 2nd page...</h4>");
		// get student details from request scope
		Student s1 = (Student) request.getAttribute("student_dtls");
		if (s1 != null) {
			pw.print("<h4> Hello ," + s1.getFirstName() + " " + s1.getLastName() + "</h4>");
			if (s1.isAdmissionStatus())
				pw.print("<h4> Congratuations upon your enrollment! </h4>");
			else
				pw.print("<h4> Sorry ! Admission denied ! </h4>");
		} else
			pw.print("<h4>RD failed !!!!!!!!!!!!!!!!</h4>");
		// what will be o/p ?
		pw.print("<h4> course " + request.getParameter("course"));// not null

	}

}
