package com.app.entities;

public enum AcctType {
SAVING,CURRENT,FD,LOAN,DMAT
}
