package com.app.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.NoArgsConstructor;

@Entity
@Table(name = "new_accts")
@NoArgsConstructor
public class BankAccount {
	@Id //OR can use @EmbeddedId
	private BankAccountPK id;
	@Column(length = 20)
	@Enumerated(EnumType.STRING)
	private AcctType type;
	@Column(length = 40)
	private String customerName;
	private double balance;
}
