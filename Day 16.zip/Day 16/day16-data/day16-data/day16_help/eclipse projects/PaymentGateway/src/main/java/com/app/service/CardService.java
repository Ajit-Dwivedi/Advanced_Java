package com.app.service;

import com.app.dto.CardDto;

public interface CardService {
 boolean verifyCardDetails(CardDto cardDto);
}
