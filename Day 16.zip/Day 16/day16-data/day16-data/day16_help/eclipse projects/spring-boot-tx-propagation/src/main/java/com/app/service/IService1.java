package com.app.service;

public interface IService1 {
	 void insertFirstAuthor();
}