package pojos;

public enum UserRole {
	ADMIN, CUSTOMER, AUTHOR
}
