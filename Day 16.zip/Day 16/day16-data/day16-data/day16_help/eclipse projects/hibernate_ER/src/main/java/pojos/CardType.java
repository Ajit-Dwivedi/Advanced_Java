package pojos;

public enum CardType {
	VISA, MASTE_CARD
}
